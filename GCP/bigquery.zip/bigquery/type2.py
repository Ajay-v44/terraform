import functions_framework
from sqlalchemy import create_engine
import pandas as pd
from google.cloud import bigquery,storage
import time
from google.cloud import secretmanager
import requests

@functions_framework.http
def main(request):
    url = "https://api.ipify.org?format=text"  # IP What's My IP service

    bucket_name = "freshivores_test"  # Replace with your GCS bucket name
    destination_blob_name = "Freshivores/table_data.csv"
    df = extract_data()
    # transformed_df = transform_data(df)
    upload_to_gcs(df, bucket_name, destination_blob_name)
    table_id ="freshivores-431302.FRESHI_TEST_BETA.beta_1"
    project_id="freshivores-431302"
    # Step 2: Load data from GCS to BigQuery
    load_from_gcs_to_bigquery(project_id,bucket_name, destination_blob_name, table_id)
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise exception for non-200 status codes
        return response.text
    except requests.exceptions.RequestException as e:
        return f"Error: {e}"

def extract_data():
    # Fetch credentials from Google Secret Manager
    client = secretmanager.SecretManagerServiceClient()

    db_user="projects/423767181723/secrets/DB_USERNAME/versions/1"
    db_user = client.access_secret_version(request={"name": db_user})
    db_password="projects/423767181723/secrets/DB_Password/versions/1"
    db_password = client.access_secret_version(request={"name": db_password})
    db_host="projects/423767181723/secrets/DB_HOST/versions/1"
    db_host = client.access_secret_version(request={"name": db_host})
    db_port="projects/423767181723/secrets/DB_PORT/versions/1"
    db_port = client.access_secret_version(request={"name": db_port})
    db_name="projects/423767181723/secrets/DB_Name/versions/1"
    db_name = client.access_secret_version(request={"name": db_name})
    
    # Connect to the MySQL database and extract data to a DataFrame
    engine = create_engine(f"mysql+mysqlconnector://{db_user.payload.data.decode('UTF-8')}:{db_password.payload.data.decode('UTF-8')}@{db_host.payload.data.decode('UTF-8')}:{db_port.payload.data.decode('UTF-8')}/{db_name.payload.data.decode('UTF-8')}")
    pd.set_option('display.max_columns', None)
    pd.set_option('display.max_rows', None)
    query = "SELECT * FROM orders  "
    df = pd.read_sql(query, engine)
    print(df.dtypes)
    df.to_csv('full_data.csv', index=False)
    return df
    
def upload_to_gcs(df, bucket_name, destination_blob_name):
    # Create a GCS client
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(destination_blob_name)
    
    # Convert DataFrame to CSV and upload to GCS
    csv_data = df.to_csv(index=False)
    blob.upload_from_string(csv_data, content_type='text/csv')
    print(f"Data uploaded to {bucket_name}/{destination_blob_name} in GCS.")

def load_from_gcs_to_bigquery(project_id,bucket_name, destination_blob_name, table_id, retries=3, delay=5):
    client = bigquery.Client(project=project_id)
    
    # Set up the load job configuration
    job_config = bigquery.LoadJobConfig(
        source_format=bigquery.SourceFormat.CSV,
        skip_leading_rows=1,  # Skip header row in the CSV
        autodetect=True,  # Let BigQuery autodetect the schema
        write_disposition=bigquery.WriteDisposition.WRITE_APPEND,
    )
    
    uri = f"gs://{bucket_name}/{destination_blob_name}"
    
    for i in range(retries):
        try:
            # Load CSV from GCS to BigQuery
            load_job = client.load_table_from_uri(
                uri,
                table_id,
                job_config=job_config,
            )
            load_job.result()  # Wait for the job to complete
            print(f"Loaded {load_job.output_rows} rows into {table_id}.")
            break
        except Exception as e:
            print(f"Failed to load data into BigQuery: {e}")
            print(f"Attempt {i + 1} failed: {e}")
            if i < retries - 1:
                print(f"Retrying in {delay} seconds...")
                time.sleep(delay)  # Wait before retrying
            else:
                print("Failed to load data into BigQuery after several attempts.")
    return "completed"


